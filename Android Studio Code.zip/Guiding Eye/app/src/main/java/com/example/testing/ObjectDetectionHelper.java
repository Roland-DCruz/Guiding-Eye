package com.example.testing;

import android.util.Log;

import org.json.JSONObject;


public class ObjectDetectionHelper {


    public String platformEdgeSafety(int x, int y, int h, int w, int imageWidth, int imageHeight) {
        // if platform on the left side.
        if (h > w && x - w / 2 < 20) {
            return ("Platform edge on the left side. Move Right");
        }

        // if platform on the right side.
        else if (h > w && (x + w / 2) >= (imageWidth - 20)) {
            return ("Platform edge on the right side. Move Left");
        }

        // if platform in front.
        else if (w > h && y <= imageHeight / 2 + 20) {
            return("Platform edge in front.");
        }
        return ("You're safe");
    }

    public String processPrediction(JSONObject prediction, int imageWidth, int imageHeight) {
        Log.d("debugtag", "prediction.lenght: "+prediction.length());
        if (prediction.length() != 0) {
            // Extract relevant information from the prediction

            Log.d("debug tag", "parameter: "+ prediction);
            int x = prediction.optInt("x");
            int y = prediction.optInt("y");
            int w = prediction.optInt("width");
            int h = prediction.optInt("height");

//            int imageWidth = prediction.optJSONObject("image").optInt("width");
//            int imageHeight = prediction.optJSONObject("image").optInt("height");

            String className = prediction.optString("class");

            // Print image dimensions
            System.out.println("Image dimensions: " + imageWidth + "x" + imageHeight);

            if ("platform_edge".equals(className)) {
                return (platformEdgeSafety(x, y, h, w, imageWidth, imageHeight));
            }
            else {
                CaptionGenerator captionGenerator = new CaptionGenerator();

                // Call the generateCaption method
                return (captionGenerator.generateCaption(className));
            }
        } else {
            return("No object detected.");
        }
    }
}
