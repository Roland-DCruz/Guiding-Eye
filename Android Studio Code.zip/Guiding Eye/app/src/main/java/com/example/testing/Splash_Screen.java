package com.example.testing;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

import com.example.testing.LanguageSelectionActivity;

public class Splash_Screen extends AppCompatActivity {
    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        // Hide the title bar and set fullscreen
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Initialize MediaPlayer and start playing audio
        mediaPlayer = MediaPlayer.create(this, R.raw.splash_audio); // Replace R.raw.splash_audio with your M4A audio file name
        mediaPlayer.start();

        // Delayed handler to move to the next activity after audio playback finishes or after 3 seconds
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Stop audio playback and start the next activity
                mediaPlayer.release(); // Release MediaPlayer resources
                Intent intent = new Intent(Splash_Screen.this, LanguageSelectionActivity.class);
                startActivity(intent);
                finish();
            }
        }, Math.max(mediaPlayer.getDuration(), 3000)); // Wait for audio to finish or 3 seconds, whichever is longer
    }

    @Override
    protected void onDestroy() {
        if (mediaPlayer != null) {
            mediaPlayer.release(); // Release MediaPlayer resources
        }
        super.onDestroy();
    }
}
