package com.example.testing;

import static com.example.testing.LanguageHelper.languageCode;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.util.Log;

import java.util.Locale;

public class TextToSpeechHelper implements OnInitListener {
    private static TextToSpeechHelper instance;  // Singleton instance
    private TextToSpeech textToSpeech;
    private Context context;

    public TextToSpeechHelper(Context context) {
        this.context = context.getApplicationContext();
        textToSpeech = new TextToSpeech(context, this);
    }

    public static synchronized TextToSpeechHelper getInstance(Context context) {
        if (instance == null) {
            instance = new TextToSpeechHelper(context);
        }
        return instance;
    }



    public void setLanguage(String languageCode) {
        if (textToSpeech != null) {
            Locale locale = new Locale(languageCode);
            int result = textToSpeech.setLanguage(locale);
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.d("tts tag", "setLanguage: Language not supported or missing data");
            } else {
                Log.d("tts tag", "setLanguage: Language set to " + languageCode);
            }
        }
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            // Use the new setLanguage method instead of hardcoding English
            setLanguage(languageCode); // Default to English for now
            Log.d("tts tag", "onInit: Initialization successful");
        } else {
            Log.d("tts tag", "onInit: Initialization failed");
        }
    }



    public void speak(String text) {
        if (textToSpeech != null) {
            textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
            Log.d("tts tag", "entered speak in tts helper ");
        } else {
            Log.d("tts tag", "textToSpeech is null");
        }
    }

    public void shutdown() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
    }
}
