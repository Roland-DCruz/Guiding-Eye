package com.example.testing;


import android.util.Log;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class CaptionGenerator {

    private static final Map<String, List<String>> captionsDict = new HashMap<>();

    static {
        captionsDict.put("divyangjan_compartment", Arrays.asList(
                "Accessible compartment for persons with disabilities.",
                "Specially designed compartment for differently-abled individuals.",
                "Divyangjan compartment ahead."
        ));

        captionsDict.put("divyangjan_sign_rectangle", Arrays.asList(
                "Divyangjan sign detected. Compartment will halt here.",
                "Sign with information for differently-abled passengers.",
                "Recognized divyangjan sign. This is the designated stop for differently abled compartment."
        ));

        captionsDict.put("divyangjan_sign_square", Arrays.asList(
                "Divyangjan sign spotted. This is where the compartment will come to a halt",
                "Signboard providing guidance for differently-abled individuals.",
                "Divyangjan sign located. This is the designated stopping point for compartment."
        ));

        captionsDict.put("platform_edge", Arrays.asList(
                "Edge of the platform at the railway station.",
                "Platform boundary for passenger safety.",
                "Area marking the edge of the platform."
        ));

        captionsDict.put("stairs", Arrays.asList(
                "Stairs for crossing the bridge.",
                "Use the stairs ahead to cross the bridge",
                "Stairs detected"
        ));

        captionsDict.put("train", Arrays.asList(
                "Railway train at the station platform.",
                "Railway train at the station platform.",
                "Railway train at the station platform."
        ));

        captionsDict.put("train_enterance", Arrays.asList(
                "Entrance to the train from the platform. Mind the gap",
                "Access point for boarding the train. Mind the gap.",
                "Gateway to board the train. Be careful, mind the gap."
        ));

        captionsDict.put("yellow_line", Arrays.asList(
                "Yellow line marking a safe boundary on the platform.",
                "Yellow safety line.",
                "Passenger safety line."
        ));
    }

    public static String generateCaption(String key) {
        Log.d("debugtag", "key: " + key);
        List<String> captions = captionsDict.get(key);
        Log.d("debugtag", "captions: " + captions);
        if (captions != null && !captions.isEmpty()) {
            Random random = new Random();
            return captions.get(random.nextInt(captions.size()));
        } else {
            return null;
        }
    }
}

