package com.example.testing;

//import static androidx.appcompat.graphics.drawable.DrawableContainerCompat.Api21Impl.getResources;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.StrictMode;
import android.widget.Toast;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.translate.Translate;
import com.google.cloud.translate.TranslateOptions;
import com.google.cloud.translate.Translation;

import java.io.IOException;
import java.io.InputStream;




public class TextConverter {

    private String inputText;
    private String desiredLanguage;
    private String translatedText;
    private boolean connected;
    private Context context; // Add this line
    Translate translate;

    public TextConverter(Context context) {
        this.context = context;
    }

    // Method to set inputText and desiredLanguage
    public void setInputAndLanguage(String inputText, String desiredLanguage) {
        this.inputText = inputText;
        if ("hindi".equalsIgnoreCase(desiredLanguage)) {
            Toast.makeText(context, "Converting to Hindi", Toast.LENGTH_SHORT).show();
            this.desiredLanguage = "hi";
        } else if ("marathi".equalsIgnoreCase(desiredLanguage)) {
            this.desiredLanguage = "mr";
            Toast.makeText(context, "Converting to Marathi", Toast.LENGTH_SHORT).show();
        } else {
            this.desiredLanguage = "en";
        }
    }

    // Method to convert text to the desired language
    public String convertText() {
        // Add your text conversion code here
        // Example: Translate inputText to desiredLanguage
        String convertedText = ""; // Placeholder for the converted text
        // Your text conversion logic goes here using inputText and desiredLanguage

        if (checkInternetConnection()) {

            //If there is internet connection, get translate service and start translation:
            getTranslateService();
            return translate();

        } else {

            //If not, display "no connection" warning:
            return ("No internet connection");
        }
    }


    public void getTranslateService() {

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try (InputStream is = context.getResources().openRawResource(R.raw.credentials)) {

            //Get credentials:
            final GoogleCredentials myCredentials = GoogleCredentials.fromStream(is);

            //Set credentials and get translate service:
            TranslateOptions translateOptions = TranslateOptions.newBuilder().setCredentials(myCredentials).build();
            translate = translateOptions.getService();

        } catch (IOException ioe) {
            ioe.printStackTrace();

        }
    }



    public String translate() {

        //Get input text to be translated:

        Translation translation = translate.translate(inputText, Translate.TranslateOption.targetLanguage(LanguageHelper.languageCode), Translate.TranslateOption.model("base"));
        translatedText = translation.getTranslatedText();

        //Translated text and original text are set to TextViews:
        return (translatedText);

    }


    public boolean checkInternetConnection() {

        //Check internet connection:
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        //Means that we are connected to a network (mobile or wi-fi)
        connected = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED;

        return connected;
    }


}
